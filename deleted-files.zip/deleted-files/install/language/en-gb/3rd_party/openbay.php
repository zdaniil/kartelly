<?php
// Heading
$_['heading_title']      = 'OpenBay Pro';

// Text
$_['text_openbay']       = 'Multi marketplace integration';
$_['text_ebay']          = 'eBay is a multi-billion dollar market place that allows business or private sellers to auction and retail goods online. Available to sellers worldwide.';
$_['text_amazon']        = 'Amazon Marketplace a fixed-price online marketplace allowing sellers to offer new and used items alongside Amazon\'s regular retail service.';

// Button
$_['button_register']    = 'Register';
$_['button_register_eu'] = 'Register Europe';
$_['button_register_us'] = 'Register USA';